package com.example.gajikaryawan;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivityAditya extends AppCompatActivity {

    Button btnGajiAditya, btnPetunjukAditya, btnTentangAditya, btnExitAditya;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_aditya);

        btnGajiAditya = findViewById(R.id.btnGajiAditya);
        btnPetunjukAditya = findViewById(R.id.btnPetunjukAditya);
        btnTentangAditya = findViewById(R.id.btnTentangAditya);
        btnExitAditya = findViewById(R.id.btnExitAditya);

        btnGajiAditya.setOnClickListener(v ->
                startActivity(new Intent(MainActivityAditya.this, GajiActivityAditya.class)));

        btnPetunjukAditya.setOnClickListener(v ->
                startActivity(new Intent(MainActivityAditya.this, PetunjukActivityAditya.class)));

        btnTentangAditya.setOnClickListener(v ->
                startActivity(new Intent(MainActivityAditya.this, TentangActivityAditya.class)));

        btnExitAditya.setOnClickListener(v ->
                new AlertDialog.Builder(MainActivityAditya.this)
                        .setTitle("Exit")
                        .setMessage("Yakin ingin keluar dari aplikasi?")
                        .setPositiveButton("Ya", (dialog, which) -> finishAffinity())
                        .setNegativeButton("Tidak", null)
                        .show());
    }
}