package com.aditya.gajikaryawanaditya;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class PetunjukActivityAditya extends AppCompatActivity {

    Button btnKembaliPetunjukAditya;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_petunjuk_aditya);

        btnKembaliPetunjukAditya = findViewById(R.id.btnKembaliPetunjukAditya);
        btnKembaliPetunjukAditya.setOnClickListener(v -> finish());
    }
}