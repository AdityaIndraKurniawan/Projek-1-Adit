package com.example.gajikaryawan;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class TentangActivityAditya extends AppCompatActivity {

    Button btnKembaliTentangAditya;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tentang_aditya);

        btnKembaliTentangAditya = findViewById(R.id.btnKembaliTentangAditya);
        btnKembaliTentangAditya.setOnClickListener(v -> finish());
    }
}